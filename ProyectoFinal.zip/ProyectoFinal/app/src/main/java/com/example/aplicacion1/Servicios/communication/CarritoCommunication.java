package com.example.aplicacion1.Servicios.communication;

public interface CarritoCommunication {
    void eliminarDetalle(String nombre);
}
